This module provides a custom formatter for imagefields, that allows the user
to specify which values (deltas) should be displayed.

Usage
-----
Go to the "Manage Display" page of your entity type, and change the formatter
for the desired image field to "Image Delta". Then click the gear icon
to configure the deltas.
